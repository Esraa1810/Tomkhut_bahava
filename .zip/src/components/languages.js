const languages = [
  { value: 'עברית', label: 'עברית' },
  { value: 'אנגלית', label: 'אנגלית' },
  { value: 'ערבית', label: 'ערבית' },
  { value: 'רוסית', label: 'רוסית' },
  { value: 'רומנית', label: 'רומנית' },
  { value: 'יידיש', label: 'יידיש' },
  { value: 'צרפתית', label: 'צרפתית' },
  { value: 'גרמנית', label: 'גרמנית' },
  { value: 'ספרדית', label: 'ספרדית' },
  { value: 'אחר', label: 'אחר' },
  // Add more languages as needed
];

export default languages;
