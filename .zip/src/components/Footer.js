// Footer.js
import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="App-footer">
      <p>עמותת תומכות באהבה ע״ר</p>
      <p>580739282</p>
      <p>0502247196</p>
      <p>tomchot.lev@gmail.com</p>
    </footer>
  );
};

export default Footer;
