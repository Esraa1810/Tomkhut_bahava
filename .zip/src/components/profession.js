

const profession =  [
    { value: 'BOT', label: 'BOT' },
    { value: 'אחות', label: 'אחות' },
    { value: 'אחות טיפת חלב' , label: 'אחות טיפת חלב' },
    { value: 'דולה', label: 'דולה' },
    { value: 'דולה לאחר לידה', label: 'דולה לאחר לידה' },
    { value: 'יועצת הנקה', label: 'יועצת הנקה' },
    { value: 'מדריכת הכנה ללידה', label: 'מדריכת הכנה ללידה' },
    { value: 'מיילדת', label: 'מיילדת' },
    { value: 'עובדת סוציאלית', label: 'עובדת סוציאלית' },
    { value: 'רפואה', label: 'רפואה' },
    { value: 'פסיכולוגית', label: 'פסיכולוגית' },
    { value: 'דולה בסטאז', label: 'דולה בסטאז' },
    { value: 'מדריכת הנקה', label: 'מדריכת הנקה' },
    { value: 'אחר', label: 'אחר' },

  ];
  
  export default profession;
  